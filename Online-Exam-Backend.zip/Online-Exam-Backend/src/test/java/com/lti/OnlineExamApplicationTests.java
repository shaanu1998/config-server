package com.lti;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.lti.entity.Subject;
import com.lti.repository.QuestionRepository;

@SpringBootTest
class OnlineExamApplicationTests {

	//@Test
	public void testCase1() {
		/*QuestionRepository q= new QuestionRepository();
		//List<Subject> list=q.getSubjects();
		//for(Subject s:list) {
			System.out.println(s.getSubjectId()+","+s.getName());
		}*/
	}

}
