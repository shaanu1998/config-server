
package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.repository.UserRepository;


@Service
public class ForgotPasswordService {
	
	@Autowired
	private UserRepository userRepository;
	
	public String forgotpassword(String emailId) {
		
		try {
			String password = userRepository.fetchByEmail(emailId);
			return password;
		}
		catch(Exception e){
			return "This mail id is not registered";
		}
		
		
		
	}
}