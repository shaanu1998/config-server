package com.lti.service;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.entity.User;
import com.lti.exception.UserServiceException;
import com.lti.repository.UserRepository;

@Service
@Transactional 
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	
	public int register(User user){

		if(userRepository.isUserPresent(user.getEmailId()))
			throw new UserServiceException("User already registerted");
		else {
				user.setPassword(Base64.getEncoder().encodeToString(user.getPassword().getBytes()));
				User updatedUser =(User) userRepository.save(user);
				return updatedUser.getUserId();
			}
		
	}
	
	public User login(String emailId,String password) {
		try {
			
			password =Base64.getEncoder().encodeToString(password.getBytes());
			int id=userRepository.fetchIdByEmailAndPassword(emailId, password);
			User user=userRepository.fetch(User.class,id);
			return user;
		}
		catch(EmptyResultDataAccessException e) {
			throw new UserServiceException("Invalid Email/Password");
		}
	}

	public User loggedInUser(int id) {
		try {
			 
			User user =(User) userRepository.fetch(User.class,id);
			return user;
			
		}
		catch(Exception e) {
			throw new UserServiceException("User not found");
	}
}
	public int updatePassword(String password) {
		try {
			password =Base64.getEncoder().encodeToString(password.getBytes());
			System.out.println(password);
			int rowsUpdated = userRepository.changePassword(password);
			return rowsUpdated;
		}
		catch(Exception e){
			return -1;
		}
	}
}
