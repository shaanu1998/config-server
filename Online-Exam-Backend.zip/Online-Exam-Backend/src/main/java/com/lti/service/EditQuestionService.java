package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.entity.Question;
import com.lti.entity.User;
import com.lti.exception.UserServiceException;
import com.lti.repository.EditQuestionRepository;

@Service
@Transactional
public class EditQuestionService {
	
	@Autowired
	private EditQuestionRepository editQuestionRepository;
	
	public Question fetchQuestion(int id ) {
		
		try {
			 
			Question quest =(Question) editQuestionRepository.fetch(Question.class, id);
			return quest;
			
		}
		catch(Exception e) {
			throw new UserServiceException("Question not found");
	}
	}
	
	public String updateLevel(int id, int level) {
		
		if(editQuestionRepository.updateQuestionLevel(id, level)) {
			return "Question Level Updated";
		} else {
			return "Question Level not updated";
		}
	}
	
	public String updateQuestions(int id, String question) {
		
		if(editQuestionRepository.updateQuestion(id, question)) {
			return "Question Updated";
		} else {
			return "Question not updated";
		}
	}
	
	public String updateOptionOnes(int id, String option) {
		
		if(editQuestionRepository.updateOptionOne(id, option)) {
			return "Option One Updated";
		} else {
			return "Option One not updated";
		}
	}
	
	public String updateOptionTwos(int id, String option) {
		
		if(editQuestionRepository.updateOptionTwo(id, option)) {
			return "Option Two Updated";
		} else {
			return "Option Two not updated";
		}
	}

	public String updateOptionThrees(int id, String option) {
	
		if(editQuestionRepository.updateOptionThree(id, option)) {
			return "Option Three Updated";
		} else {
			return "Option Three not updated";
		}
	}

	public String updateOptionFours(int id, String option) {
	
		if(editQuestionRepository.updateOptionFour(id, option)) {
			return "Option Four Updated";
		} else {
			return "Option Four not updated";
		}
	}
	
	public String updateAns(int id, String answer) {
		
		if(editQuestionRepository.updateAnswer(id, answer)) {
			return "Answer Updated";
		} else {
			return "Answer not updated";
		}
	}
	
	public String updateStatusOfQuestion(int id) {
		
		if(editQuestionRepository.updateQuestionStatus(id)) {
			return "Status Updated";
		} else {
			return "Status not updated";
		}
	}

}
