package com.lti.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

@Repository
public class EditQuestionRepository extends GenericRepository{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public boolean updateQuestionLevel(int id, int level) {
		
		return entityManager
				.createQuery("UPDATE Question q SET q.level = :level WHERE q.questionId = :id")
				.setParameter("level", level)
				.setParameter("id", id)
				.executeUpdate() == 1 ? true:false;
	}
	
	public boolean updateQuestion(int id, String question) {
		
		return entityManager
				.createQuery("UPDATE Question q SET q.question = :quest WHERE q.questionId = :id")
				.setParameter("quest", question)
				.setParameter("id", id)
				.executeUpdate() == 1 ? true:false;
	}
	
	public boolean updateOptionOne(int id, String option) {
		
		return entityManager
				.createQuery("UPDATE Question q SET q.option1 = :opt WHERE q.questionId = :id")
				.setParameter("opt", option)
				.setParameter("id", id)
				.executeUpdate() == 1 ? true:false;
	}
	
	public boolean updateOptionTwo(int id, String option) {
		
		return entityManager
				.createQuery("UPDATE Question q SET q.option2 = :opt WHERE q.questionId = :id")
				.setParameter("opt", option)
				.setParameter("id", id)
				.executeUpdate() == 1 ? true:false;
	}
	
	public boolean updateOptionThree(int id, String option) {
		
		return entityManager
				.createQuery("UPDATE Question q SET q.option3 = :opt WHERE q.questionId = :id")
				.setParameter("opt", option)
				.setParameter("id", id)
				.executeUpdate() == 1 ? true:false;
	}
	
	public boolean updateOptionFour(int id, String option) {
		
		return entityManager
				.createQuery("UPDATE Question q SET q.option4 = :opt WHERE q.questionId = :id")
				.setParameter("opt", option)
				.setParameter("id", id)
				.executeUpdate() == 1 ? true:false;
	}
	
	public boolean updateAnswer(int id, String answer) {
		
		return entityManager
				.createQuery("UPDATE Question q SET q.answer = :ans WHERE q.questionId = :id")
				.setParameter("ans", answer)
				.setParameter("id", id)
				.executeUpdate() == 1 ? true:false;
	}
	
	public boolean updateQuestionStatus(int id) {
		
		return entityManager
				.createQuery("UPDATE Question q SET q.status = :stat WHERE q.questionId = :id")
				.setParameter("stat", "Active")
				.setParameter("id", id)
				.executeUpdate() == 1 ? true:false;
	}

}
