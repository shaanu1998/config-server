package com.lti.controller;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dto.ForgotPasswordStatus;
import com.lti.dto.Login;
import com.lti.dto.LoginStatus;
import com.lti.dto.Password;
import com.lti.dto.RegisterStatus;
import com.lti.dto.Status;
import com.lti.entity.User;
import com.lti.exception.UserServiceException;
import com.lti.service.EmailService;
import com.lti.service.ForgotPasswordService;
import com.lti.service.UserService;

@RestController
@CrossOrigin
public class UserController {
	
	@Autowired
	private UserService userService;
	@Autowired
	private EmailService mailService;
	@Autowired
	private ForgotPasswordService forgotPasswordService;

	
	@PostMapping("/register")
	public RegisterStatus register(@RequestBody User user){
		try {
			int id = userService.register(user);
			RegisterStatus status = new RegisterStatus();
			status.setStatus(true);
			status.setMessage("Registration successful");
			status.setRegisteredUserId(id); 
			mailService.sendEmail(user.getEmailId(),"Registration Successful","ONLINE-EXAM");
			System.out.println("Email Sent Successfully");
			return status; 
		}
		catch(UserServiceException e){
			RegisterStatus status = new RegisterStatus();
			status.setStatus(false);
			status.setMessage(e.getMessage());
			return status;
		}
     }
	
	@PostMapping("/login")
	public LoginStatus login(@RequestBody Login login) {
		try {
			System.out.println(login.getEmailId()+","+login.getPassword());
			User user=userService.login(login.getEmailId(), login.getPassword());
			LoginStatus loginStatus=new LoginStatus();
			loginStatus.setStatus(true);
			loginStatus.setMessage("Login Successfull!!");
			loginStatus.setUserId(user.getUserId());
			loginStatus.setName(user.getName());
			
			return loginStatus;
		}
		catch(UserServiceException e){
			LoginStatus loginStatus =new LoginStatus();
			loginStatus.setStatus(false);
			loginStatus.setMessage(e.getMessage());
			
			return loginStatus;
		}
	}   
	
	@PostMapping("/profile")
	public User profile(@RequestBody User user) {
		try {
			
			System.out.println(user.getUserId()+","+"user id");	
			User user1 =(User) userService.loggedInUser(user.getUserId());
		
		    System.out.println(user1.getName());
		    System.out.println(user1.getEmailId());
		    System.out.println(user1.getMobileNo());
		    
		    user.setName(user1.getName());
		    user.setEmailId(user1.getEmailId());
		    user.setQualification(user1.getQualification());
		   
		    return user;
			
		}
		catch(UserServiceException e){
			
			return null;
						
		}
		
	}
	
	@PostMapping("/forgotpassword")
	public ForgotPasswordStatus forgotpassword(@RequestBody Login login) {
		
		try 
		{
			String password = forgotPasswordService.forgotpassword(login.getEmailId());
			if(!password.equals("This mail id is not registered")) {
				mailService.sendEmail(login.getEmailId(),"Here is the link to reset your password"+" http://localhost:4200/change-password","ONLINE-EXAM");
				ForgotPasswordStatus forgotPasswordStatus = new ForgotPasswordStatus();
				forgotPasswordStatus.setStatus(true);
				forgotPasswordStatus.setMessage("User Exists");
				return forgotPasswordStatus;
			}
			else
			{
				ForgotPasswordStatus forgotPasswordStatus = new ForgotPasswordStatus();
				forgotPasswordStatus.setStatus(false);
				forgotPasswordStatus.setMessage("User does not exist");
				return forgotPasswordStatus;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
			ForgotPasswordStatus forgotPasswordStatus = new ForgotPasswordStatus();
			forgotPasswordStatus.setStatus(false);
			forgotPasswordStatus.setMessage("User does not exist");
			return forgotPasswordStatus;
		}
	}
	
	@PostMapping("/changepassword")
	public Status changepassword(@RequestBody Password pass) {
		try {
			String password = pass.getPassword();
			int rowsUpdated = userService.updatePassword(password);
			System.out.println(rowsUpdated);
			Status status = new Status();
			status.setStatus(true);
			status.setMessage("Password Changed Successfully");
			return status;
		}
		catch(Exception e)
		{
			Status status = new Status();
			status.setStatus(false);
			status.setMessage("Sorryy,There was an error in changing the password");
			return status;
		}
	} 
	
}

