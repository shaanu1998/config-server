package com.lti.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lti.entity.Question;
import com.lti.service.EditQuestionService;

@RestController
@CrossOrigin
public class EditQuestionController {
	
	@Autowired
	private EditQuestionService editQuestionService;
	
	@GetMapping("/getQuestion")
	public Question getQuestion(@RequestParam("id") int id) {
		return editQuestionService.fetchQuestion(id);
		
	}
	
	@GetMapping("/editLevel")
	public String questionLevel(@RequestParam("id") int id, @RequestParam("level") int level) {
		return editQuestionService.updateLevel(id, level);
	}
	
	@GetMapping("/editQuestion")
	public String questions(@RequestParam("id") int id, @RequestParam("question") String question) {
		return editQuestionService.updateQuestions(id, question);
	}
	
	@GetMapping("/editOptionOne")
	public String optionOne(@RequestParam("id") int id, @RequestParam("option") String option) {
		return editQuestionService.updateOptionOnes(id, option);
	}
	
	@GetMapping("/editOptionTwo")
	public String optionTwo(@RequestParam("id") int id, @RequestParam("option") String option) {
		return editQuestionService.updateOptionTwos(id, option);
	}
	
	@GetMapping("/editOptionThree")
	public String optionThree(@RequestParam("id") int id, @RequestParam("option") String option) {
		return editQuestionService.updateOptionThrees(id, option);
	}
	
	@GetMapping("/editOptionFour")
	public String optionFour(@RequestParam("id") int id, @RequestParam("option") String option) {
		return editQuestionService.updateOptionFours(id, option);
	}
	
	@GetMapping("/editAnswer")
	public String answer(@RequestParam("id") int id, @RequestParam("answer") String answer) {
		return editQuestionService.updateAns(id, answer);
	}
	
	@GetMapping("/editStatus")
	public String status(@RequestParam("id") int id) {
		return editQuestionService.updateStatusOfQuestion(id);
	}

}
